Put gamestate_integration_statetrak.cfg

in Steam\steamapps\common\Counter-Strike Global Offensive\csgo\cfg

Start the program by going to Start -> Start Server